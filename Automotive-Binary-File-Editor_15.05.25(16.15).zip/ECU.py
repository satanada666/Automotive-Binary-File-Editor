class ECU:
    def __init__(self, name):
        self.name = name
        self.children = []

class EEPROMNode:
    def __init__(self, name):
        self.name = name
        self.children = []

class DASHNode:
    def __init__(self, name):
        self.name = name
        self.children = []

class BCMNode:
    def __init__(self, name):
        self.name = name
        self.children = []
