from encoder import Encoder
from dash_editor import DashEditor

class eeprom(Encoder):
    def __init__(self):
        super().__init__()

class srs(Encoder):
    def __init__(self):
        super().__init__()